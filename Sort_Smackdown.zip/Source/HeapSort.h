#include "Globals.h"

template <typename T>
class cHeapSort
{
	public:
		cHeapSort()
		{



		};
		~cHeapSort()
		{
		

		};

		void Sort(deque<T> &list);

	private:
		void Heaplist(deque<T> &list, unsigned int root, unsigned int end);
};

template <typename T>
void cHeapSort<T>::Sort(deque<T> &list)
{
	if(list.empty())
	{
		cout <<"List passed to heapsort is empty!!\n";
		return;
	}

	//Bottom to top (/2 = last parent (-1 for 0 based))
	for(int x = (list.size() / 2)-1; x >= 0; x--)
		Heaplist(list, x, list.size()-1);
	
	//Now it is a true heap binary tree
	//So now, lets sort it.. switch the root multiple times
	for(int y = list.size()-1; y >= 1; y--)
	{
		//switch the root to the end of the list and then reheap it
		static T temp;
		temp = list[0];
		list[0] = list[y];
		list[y] = temp;

		//Now the max value(root) is at the end of the list
		//lets rebuild the heap
		Heaplist(list, 0, y-1);
	}
};

template <typename T>
void cHeapSort<T>::Heaplist(deque<T> &list, unsigned int root, unsigned int end)
{
	bool Exit = false;
	static unsigned int maxChild;

	//test left child against ending
	while(((root*2) <= end) && Exit != true)
	{
		//Test for which one to possibly make parent node and test for out of range
		if(root*2 == end || ((root*2)+1) >= end)
			maxChild = root * 2;
		else if(list[root*2] > list[root*2 + 1])
			maxChild = root * 2;
		else
			maxChild = root*2 + 1;
		
		//Test left or ride child against parent and switch if needed
		if(list[root] < list[maxChild])
		{
			static T temp;
			temp = list[root];
			list[root] = list[maxChild];
			list[maxChild] = temp;

			root = maxChild;
		}
		else
			Exit = true;
	}
};