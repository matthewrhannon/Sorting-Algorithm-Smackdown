#include "Globals.h"

template <typename T>
class cRadixSort 
{
	public:
		cRadixSort()
		{
			deque<T> temp;

			//Initalize Organizer
			for(int x = 0; x < 10; x++)
				Organizer.push_back(temp);
		};

		~cRadixSort() {};
	
		void Sort(deque<T> &List);

	private:
		deque< deque<T> > Organizer; 
};


template <typename T>
void cRadixSort<T>::Sort(deque<T> &List)
{
	if(List.empty())
	{
		cout << "List is empty!!\n";
		return;
	}

	//Find Maxvalue
	T MaxValue = List[0];

	for(unsigned int x = 1; x < List.size(); x++)
	{
		if(List[x] > MaxValue)
			MaxValue = List[x];
	}

	//Get # of digits in maxvalue
	unsigned int NumberOfDigits = 0;

	while(MaxValue > 0)
	{
		NumberOfDigits++;
		MaxValue /= 10;
	}

	//Now do radix sort
	unsigned int DigitPlace = 1, Place = 0, ZeroCheck;

	while(NumberOfDigits != 0)
	{
		for(unsigned int x = 0; x < List.size(); x++)
		{
			//Get value at current digitplace in current index
			ZeroCheck = List[x]/DigitPlace;

			if(ZeroCheck >= 1)
				Place = (ZeroCheck % 10);
			else
				Place = 0;

			//Set digit in correct place in organizer
			Organizer[Place].push_back(List[x]);
		}

		//Zero List
		List.clear();

		//Now refill List in a much nicer order
		for(int x = 0; x < 10; x++)
		{
			Place = 0;

			while(!Organizer[x].empty())
			{
				List.push_back(Organizer[x].front());
				Organizer[x].pop_front();
			}
		}

		//Up to the next digit
		DigitPlace *= 10;
		NumberOfDigits--;
	}
}