//Sort smackdown
//Matt Hannon March 18th 2007

#ifndef GLOBALS_ONCE
#define GLOBALS_ONCE

//Annoying warnings
#pragma warning(disable : 4018)
#pragma warning(disable : 4267)

//C++
#include <iostream>
#include <deque>

using namespace std;

//Other
#include <windows.h>
#include <stdio.h>
#include <time.h>

#define inline __forceinline

#endif

