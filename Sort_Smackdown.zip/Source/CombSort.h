#include "Globals.h"

template <typename Type>
class cCombSort
{
	public:
		cCombSort() 
		{
			Swaped = false;
		};

		~cCombSort() { };

		void Sort(deque<Type> &List);
	private:
		unsigned int Gap;
		bool Swaped;

};

template <typename Type>
void cCombSort<Type>::Sort(deque<Type> &List)
{
	if(List.empty())
	{
		cout << "A empty list is passed to combosrt!";
		return;
	}

	Gap = (unsigned int)List.size();

	//Loop until gap = 1 and zero swaps
	while(Gap != 1 || !Swaped)
	{
		Swaped = false;
		
		//The magic
		if(Gap > 1)
		{
			Gap = unsigned int(Gap / 1.3);
			
			//Make sure we get all turtles
			if(Gap == 10 || Gap == 9)
				Gap = 11;
		}

		for(unsigned int x = 0; (x+Gap) < List.size(); x++)
		{
			if(List[x] > List[x+Gap])
			{
				//Swap them
				static Type temp;
				temp = List[x];
				List[x] = List[x+Gap];
				List[x+Gap] = temp;

				Swaped = true;
			}
		}
	}
}