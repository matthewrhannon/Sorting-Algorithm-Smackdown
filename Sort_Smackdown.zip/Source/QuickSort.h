#include "Globals.h"

template<typename T>
class cQuickSort
{
	public:
		cQuickSort() { };
		~cQuickSort() { };

		void Sort(deque<T> &list);
	private:
		void qSort(deque<T> &list, unsigned int left, unsigned int right);
		
		inline void Swap(T &element, T &element1)
		{
			static T temp; //Save some memory
			temp = element1;
			element1 = element;
			element = temp;
		};

		T Pivot;
		unsigned int Size;
};

template<typename T>
void cQuickSort<T>::Sort(deque<T> &list)
{
	//A 1 size is already sorted
	if(list.size() <= 1)
	{
		cout << "Invalid size passed to qSort\n";
		return;
	}

	Size = list.size();

	//Size-1 because array starts at 0
	qSort(list, 0, Size-1);

	//Array should now be sorted.. hopefully
}

template<typename T>
void cQuickSort<T>::qSort(deque<T> &list, unsigned int left, unsigned int right)
{
	int numberOfElements = right-left;

	if(numberOfElements > 0)
	{
		//Defiantly know atleast 2 elements so test them to save loop cycles
		if(list[left] > list[right])
			Swap(list[left], list[right]);

		if(numberOfElements > 1)
		{ //More than just 2 elements

			//Calculate low and high values and store at left and right
			for(unsigned int x = left+1; x < right; x++)
			{
				if(list[x] < list[left]) 
					Swap(list[x], list[left]);
				else if(list[x] > list[right])
					Swap(list[x], list[right]);
			}

			//Now need to find actual pivot value which would be the mean
			unsigned int mean = (list[right]+list[left])/2;
			Pivot = list[left+1];

			//+2 because cant be least value and first guess is +1; -1 cant be high value
			for(unsigned int x = left+1; x < right-1; x++)
			{
				if(abs(int(mean-list[x])) < abs(int(mean-Pivot)))
					Pivot = list[x];
			}
			
			//Pivot = list[left];
			
			//We now have our pivot, so lets sort around it
			unsigned int l = left+1;
			unsigned int r = right-1; //remove -1 if not calculating mean

			while(l < r)
			{
				//Go until we have a pair of elements to be switched
				while(list[l] < Pivot) l++;
				while(list[r] > Pivot) r--;

				//Make sure not at Pivot
				if(l < r)
					Swap(list[l], list[r]);

				//Exit loop
				if(list[l] == Pivot && list[r] == Pivot)
					l++;
			}

			//Now elements should be sorted around the pivot
			qSort(list, left+1, r-1);
			qSort(list, r+1, right-1);
		}
	}
}
