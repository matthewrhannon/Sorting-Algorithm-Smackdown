#include "Globals.h"

template <typename Type>
class cBucketSort
{
	public:
		cBucketSort() { };
		~cBucketSort() { };

		void Sort(deque<Type> &List);
	private:
		Type *SortList;

		unsigned int maxValue;
		unsigned int Size, Count;
};

template <typename Type>
void cBucketSort<Type>::Sort(deque<Type> &List)
{
	maxValue = 0;
	Count = 0;

	if(List.empty())
	{
		cout << "List given to bucketsort is empty!";
		return;
	}
	
	Size = (unsigned int)List.size();

	//Find max
	for(unsigned int x = 0; x < Size; x++)
	{
		if(List[x] > maxValue)
			maxValue = List[x];
	}

	//Add 1 to maxvalue so we can use 0
	maxValue++;

	SortList = new Type[maxValue];

	for(unsigned int x = 0; x < maxValue; x++)
		SortList[x] = 0;

	for(unsigned int x = 0; x < Size; x++)
		SortList[List[x]]++;

	//List.clear();

	for(unsigned int x = 0; x < maxValue; x++)
	{
		while(SortList[x] != 0)
		{
			//List.push_back(x);
			List[Count++] = x;
			SortList[x]--;
		}
	}

	delete []SortList;

	//Now sorted
}
