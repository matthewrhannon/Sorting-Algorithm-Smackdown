/* combo sortt
#include "Globals.h"

template <typename T>
class cBitwiseSort
{
	public:
		cBitwiseSort()
		{ 
			Done = false;
		};
		~cBitwiseSort()
		{

		};

		bool Sort(deque<T> &Items);
	private:
		//functions
		void BitSort(deque<T> &Items);
		virtual void GenericSort(deque<T> &List, int Start, int End);

		inline void Swap(T &num1, T &num2)
		{
			static T temp;

			temp = num1;
			num1 = num2;
			num2 = temp;
		};

		int curBit;
		unsigned int sizeOfElement, Elements, MSB;
		T maxValue, minValue;
		bool Done;
};

template<typename T>
bool cBitwiseSort<T>::Sort(deque<T> &Items)
{
	if(Items.size() < 2)
	{
		cout << "Bad sized passed to bitwise sort\n";
		return false;
	}

	sizeOfElement = sizeof(T);
	Elements = Items.size();

	//Find max and min elements
	maxValue = 0;
	minValue = Items[0];

	for(unsigned int x = 0; x < Elements; x++)
	{
		if(Items[x] > maxValue)
			maxValue = Items[x];
	}

	//Calculate MSB of max
	MSB = (sizeOfElement*8)-1; //must account for 0
	while(!(maxValue & 1<<MSB))
		MSB--;

	BitSort(Items);

	return true;
}

template<typename T>
void cBitwiseSort<T>::BitSort(deque<T> &Items)
{
	static unsigned int numSorting = Elements, numSorted = Elements;

	for(curBit = MSB; curBit >= 0; curBit--) //must include 0
	{
		for(int index = 0; index < numSorting; index++)
		{
			//check if current bit is selected
			if(Items[index] & 1<<curBit)
			{
				//semi big value so put at end
				Swap(Items[index], Items[--numSorting]);
				//Now redo index because its a new value
				index--;
			}
		}

		//Now biggest values are at end of list, so sort em!
		if((numSorted - numSorting) > 0)
		{
			GenericSort(Items, numSorting, numSorted);
			numSorted = numSorting;
		}
	}
}
//change this up.... appeal to the inplace sorting... how to come up with something faster than bucket? impossible?
template<typename T>
void cBitwiseSort<T>::GenericSort(deque<T> &List, int Start, int End)
{
	static unsigned int Gap;

	Gap = (unsigned int)End-Start;

	//Loop until gap = 1 and zero swaps
	while(Gap != 1)
	{
		//The magic
		if(Gap > 1)
		{
			Gap = unsigned int(Gap / 1.3);
			
			//Make sure we get all turtles
			if(Gap == 10 || Gap == 9)
				Gap = 11;
		}

		for(unsigned int x = Start; (x+Gap) < End; x++)
		{
			if(List[x] > List[x+Gap])
			{
				//Swap them
				Swap(List[x], List[x+Gap]);
			}
		}
	}	
}

*/

#include "Globals.h"

template <typename T>
class cBitwiseSort
{
	public:
		cBitwiseSort()
		{ 
			Done = false;
			Buckets = 0;
		};
		~cBitwiseSort()
		{

		};

		bool Sort(deque<T> &Items);
	private:
		//functions
		void BitSort(deque<T> &Items);
		virtual void GenericSort(deque<T> &Items, unsigned int Start, unsigned int End);

		//varibles
		unsigned int *Buckets;

		inline void Swap(T &num1, T &num2)
		{
			static T temp;

			temp = num1;
			num1 = num2;
			num2 = temp;
		};

		int curBit;
		unsigned int sizeOfElement, Elements, MSB;
		T maxValue, minValue, biggestValue; //fix type later
		bool Done;
};

template<typename T>
bool cBitwiseSort<T>::Sort(deque<T> &Items)
{
	if(Items.size() < 2)
	{
		cout << "Bad sized passed to bitwise sort\n";
		return false;
	}

	sizeOfElement = sizeof(T);
	Elements = Items.size();

	//Find max and min elements
	maxValue = 0;
	minValue = Items[0];

	for(unsigned int x = 0; x < Elements; x++)
	{
		if(Items[x] > maxValue)
			maxValue = Items[x];
		//else if(Items[x] < minValue)
		//	minValue = Items[x];
	}

	//Calculate MSB of max
	MSB = (sizeOfElement*8)-1; //must account for 0
	while(!(maxValue & 1<<MSB))
		MSB--;

	//Must be +1 because using 0
	if(!Buckets)
	{
		//Calculate practically biggestpossible -1 (overkill)
		//biggestValue = unsigned(~(1<<MSB));
		//for(int x = (sizeOfElement*8)-1; x > MSB; x--)
			//biggestValue ^= 1<<x;
		
		biggestValue = unsigned(1<<MSB)-1;
		biggestValue++;
		Buckets = new unsigned int[biggestValue];

		//if(maxValue > biggestValue)
			//cout << "WOOO HOOOO " << maxValue - biggestValue << endl;

		//Set them to 0
		for(unsigned int x = 0; x < biggestValue; x++)
			Buckets[x] = 0;
	}

	BitSort(Items);

	delete []Buckets;
	return true;
}

template<typename T>
void cBitwiseSort<T>::BitSort(deque<T> &Items)
{
	static unsigned int numSorting = Elements, numSorted = Elements;

	for(curBit = MSB; curBit >= 0; curBit--) //must include 0
	{
		for(int index = 0; index < numSorting; index++)
		{
			//check if current bit is selected
			if(Items[index] & 1<<curBit)
			{
				//semi big value so put at end
				Swap(Items[index], Items[--numSorting]);
				//Now redo index because its a new value
				index--;
			}
		}

		//Now biggest values are at end of list, so sort em!
		if(unsigned(numSorted - numSorting) > 0)
		{
			GenericSort(Items, numSorting, numSorted);
			numSorted = numSorting;
		}
	}
}
//change this up.... appeal to the inplace sorting... how to come up with something faster than bucket? impossible?
template<typename T>
void cBitwiseSort<T>::GenericSort(deque<T> &Items, unsigned int Start, unsigned int End)
{
	static unsigned int numBucket = (maxValue) ^ 1<<MSB;
	static bool bigSet = false;

	//Set the buckets
	if(!bigSet)
	{
		for(unsigned int x = Start; x < End; x++)
			Buckets[Items[x] ^ 1<<MSB]++;
	}
	else
	{
		for(unsigned int x = Start; x < End; x++)
			Buckets[Items[x]]++;
	}

	if(!bigSet)
	{
		bigSet = true;

		for(unsigned int x = 0; x < numBucket; x++)
		{
			while(Buckets[x] != 0)
			{
				Items[Start++] = (x | 1<<MSB);
				Buckets[x]--;
			}
		}
	}
	else
	{
		for(unsigned int x = 1<<curBit; x < numBucket-1; x++)
		{
 			while(Buckets[x] != 0)
			{
				Items[Start++] = x;
				Buckets[x]--;
			}
		}
	}

	numBucket = 1<<curBit;
}


/*
//change this up.... appeal to the inplace sorting... how to come up with something faster than bucket? impossible?
template<typename T>
void cBitwiseSort<T>::GenericSort(deque<T> &Items, unsigned int Start, unsigned int End)
{
	static unsigned int numBucket = maxValue+1;

	//Set the buckets
	for(unsigned int x = Start; x < End; x++)
		Buckets[Items[x]]++;
	
	for(unsigned int x = 1<<curBit; x < numBucket; x++)
	{
		while(Buckets[x] != 0)
		{
			Items[Start++] = x;
			Buckets[x]--;
		}
	}

	numBucket = 1<<curBit;
}
*/