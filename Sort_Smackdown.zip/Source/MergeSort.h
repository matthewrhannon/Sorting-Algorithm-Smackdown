#include "Globals.h"

template <typename T>
class cMergeSort
{
	public:
		cMergeSort() { };
		~cMergeSort() { };

		deque<T> sort(deque<T> list);
	private:
		deque<T> arrange(deque<T> left, deque<T> right);
};

template <typename T>
deque<T> cMergeSort<T>::arrange(deque<T> left, deque<T> right)
{
	deque<T> result;

	//traverse through each list
	while((left.size() > 0) && (right.size() > 0))
	{
		if(left.front() <= right.front())
		{
			result.push_back(left.front());
			left.pop_front();
		}
		else
		{
			result.push_back(right.front());
			right.pop_front();
		}
	}

	//handle last entry not handled
	while(left.size() > 0)
	{
		result.push_back(left.front());
		left.pop_front();
	}
	while(right.size() > 0)
	{
		result.push_back(right.front());
		right.pop_front();
	}

	return result;
}

template <typename T>
deque<T> cMergeSort<T>::sort(deque<T> list)
{
	deque<T> left, right, result;

	if(list.size() <= 1)
		return list;
	else
	{
		int middle = (int)list.size()/2;
		int x = 0;

		//Now fill left and right lists
		while(x < middle)
		{
			left.push_back(list[x]);
			x++;
		}

		while(x < list.size())
		{
			right.push_back(list[x]);
			x++;
		}

		left = sort(left);
		right = sort(right);
		result = arrange(left, right);
	}

	//at the last recursive cycle, this will be our complete sorted array.. hopefully
	return result;
}