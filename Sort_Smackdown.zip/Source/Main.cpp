//Written by Matthew Hannon

#include "Globals.h"

#include "BucketSort.h"
#include "CombSort.h"
#include "HeapSort.h"
#include "MergeSort.h"
#include "QuickSort.h"
#include "RadixSort.h"
#include "BitwiseSort.h"

#define AMOUNT 500000
#define MAX_RAND 1000

#define TYPE  int

int main()
{
	unsigned long Start = 0, End = 0;
	srand((unsigned int)time(NULL));

	deque<TYPE> Items, RandomItems;

	for(int x = 0; x < AMOUNT; x++)
		Items.push_back(rand() % MAX_RAND);

	RandomItems = Items;

	cout << "Sort Smackdown by Matthew Hannon\n";
	cout << "Program is sorting " << AMOUNT << " items in a range of 0 to " << MAX_RAND << ".\n\n";
	
	cout << "This list of soon to be sorted items is:\n";

	//for(int x = 0; x < AMOUNT; x++)
	//	cout << Items[x] << " ";

	//Sorting time!
	cout << endl;
	system("pause");
	cout << endl;

	//Bucket first
	{
		cBucketSort<TYPE> bucket;

		Start = GetTickCount();
		bucket.Sort(Items);
		End = GetTickCount();

		cout << "Bucket sort completed in " << End-Start << " .ms.\n";
		Items = RandomItems;
	}
	
	//Comb sort
	{
		cCombSort<TYPE> comb;

		Start = GetTickCount();
		comb.Sort(Items);
		End = GetTickCount();

		cout << "Comb sort completed in " << End-Start << " .ms.\n";
		Items = RandomItems;
	}

	//Heap sort
	{
		cHeapSort<TYPE> heap;

		Start = GetTickCount();
		heap.Sort(Items);
		End = GetTickCount();

		cout << "Heap sort completed in " << End-Start << " .ms.\n";
		Items = RandomItems;
	}

	//Merge sort
	{
		cMergeSort<TYPE> merge;

		Start = GetTickCount();
		Items = merge.sort(RandomItems);
		End = GetTickCount();

		cout << "Merge sort completed in " << End-Start << " .ms.\n";
		Items = RandomItems;
	}

	//Quick sort
	{
		cQuickSort<TYPE> quick;

		Start = GetTickCount();
		quick.Sort(Items);
		End = GetTickCount();

		cout << "Quick sort completed in " << End-Start << " .ms.\n";
		Items = RandomItems;
	}

	//Radix sort
	{
		cRadixSort<TYPE> radix;

		Start = GetTickCount();
		radix.Sort(Items);
		End = GetTickCount();

		cout << "Radix sort completed in " << End-Start << " .ms.\n";
		Items = RandomItems;
	}
	
	//Bitwise sort
	{
		cBitwiseSort<TYPE> bit;

		Start = GetTickCount();
		bit.Sort(Items);
		End = GetTickCount();

		cout << "Bit sort completed in " << End-Start << " .ms.\n";
		Items = RandomItems;
	}

	//for(int x = 0; x < AMOUNT; x++)
	//	cout << Items[x] << " ";
	system("pause");




	return 1;
}